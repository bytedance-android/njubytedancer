package com.byted.camp.todolist.db;

/**
 * @author zhongshan
 * @date 2021-04-19
 */
public final class TodoContract {

    // TODO 定义表结构和 SQL 语句常量

    private TodoContract() {
    }

}
