package com.byted.camp.video;

import android.app.Application;

public class StudyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
