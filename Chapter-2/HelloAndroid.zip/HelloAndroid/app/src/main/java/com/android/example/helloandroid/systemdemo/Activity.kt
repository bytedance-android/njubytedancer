package com.android.example.helloandroid.systemdemo

/**
 * 示例 activity
 *
 * @author 高超（gaochao.cc）
 * @since 2021/6/13
 */
class Activity {
    fun onCreate() {

    }

    fun onStart() {

    }

    fun onResume() {

    }

    fun onPause() {

    }

    fun onStop() {

    }

    fun onDestroy() {

    }
}